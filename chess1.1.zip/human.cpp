#include <iostream>
#include "human.h"
#include "game.h"
#include "board.h"

using namespace std;

Human::Human(string name, Color color) : Player(name, color) { }

void Human::makeMove(Board* board) {
    while (true) {
        cout << this->getName() <<  "'s turn: ";
        char c1, c2;    // columns letters
        int r1, r2;     // row indexes (begin at 1)
        cin >> c1 >> r1 >> c2 >> r2;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "invalid input!" << endl;
            continue;
        }
        
        // ad hoc stop condition
        if (c1 == 'Z' && c2 == 'Z' && r1 == 0 && r2 == 0) {
            board->getGame()->setState(STOPPED);
            return;
        }
        
        // TODO:
        // Convert r1, c1 and r2, c2 into integers y1, x1, y2, x2 
        int y1 = r1 - 1;
        int y2 = r2 - 1;
        int x1, x2;

        if (c1 >= 'A' && c1 <= 'H')
        {
            x1 = int(c1 - 'A');
        }
        else
        {
            x1 = int(c1 - 'a');
        }
        
        if (c2 >= 'A' && c2 <= 'H')
        {
            x2 = int(c2 - 'A');
        }
        else
        {
            x2 = int(c2 - 'a');
        }
        
        bool valid = board->move(y1, x1, y2, x2);
        if (valid)
            break;
        cout << "invalid input!" << endl;
    }
}
//done