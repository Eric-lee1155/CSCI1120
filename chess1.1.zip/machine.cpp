#include <iostream>
#include "machine.h"
#include "board.h"
#include <ctime>

using namespace std;

const int TRIALS = 4096;    // 64 x 64

Machine::Machine(string name, Color color) : Player(name, color) {
    // randomize the seed
    srand(static_cast<unsigned int>(time(nullptr)));
}

// a sample machine that makes random but valid moves
void Machine::makeMove(Board* board) {
    for (int i = 0; i < 10 * getPieceCount(); i++) {
        int j = rand() % getPieceCount();
        Piece* p = getPiece(j);
        int y1 = p->getY();
        int x1 = p->getX();
        
        // TODO: 
        // write a loop to repeat below at most TRIALS times:
        // - generate random integers y2 and x2 in range of [0, H) and [0, W) respectively
        // - call board's move(y1, x1, y2, x2)
        // - once a valid move is returned, print the from and to cell addresses 
        //   and exit this function

        //initalize necessary variables
        int count=0;
        bool isMovepos = false;
        int y2=0, x2=0;

        //testing the destination is vaild again and again until the it is vaild or reach the maximum trial
        do
        {
            y2 = rand() % H;
            x2 = rand() % W;
            isMovepos = board->move(y1, x1, y2, x2);
            count++;

        } while (count <= TRIALS && isMovepos == false);

        //once a valid move is returned, print the from and to cell addresses
        if (isMovepos)
        {
            cout << this->getName() << "'s turn: ";
            cout << char(x1 + 'A') << y1 + 1 << " " << char(x2 + 'A') << y2 + 1 << endl;
            break;

        }

    }
}
//done
