#include "game.h"
#include "board.h"
#include "Rook.h"

//const int DY[] = { -1, -1,  0,  1,  1,  1,  0, -1 };
//const int DX[] = { 0,  1,  1,  1,  0, -1, -1, -1 };
// N  NE   E  SE   S  SW   W  NW
const int DY[] = { -1,  0,  1,  0};
const int DX[] = { 0,  1,  0, -1};


Rook::Rook(Color color, int y, int x, Board* board) : Piece(color, y, x, board) {
    setLabel(letter(ROOK));
    setScore(ROOK_POINTS);
}

bool Rook::isMoveValid(int y, int x) {
    Board* board = getBoard();
    for (int d = 0; d < 4; d++) {
        for (int l = 1; l < 8; l++)
        {
            //checking whether the target position is lies on the path
            if (y == getY() + l * DY[d] && x == getX() + l * DX[d]) {
                Piece* target = board->get(getY() + l * DY[d], getX() + l * DX[d]);
                // move to an empty cell or capture opponent piece
                if (target == EMPTY || target->getColor() != this->getColor())
                    return true;
            }
            //checking whether the path is out of bound
            if (0 <= getY() + l * DY[d] && getY() + l * DY[d] < H && 0 <= getX() + l * DX[d] && getX() + l * DX[d] < W)
            {
                //checking whether the path is blocked
                if (board->get(getY() + l * DY[d], getX() + l * DX[d])!= EMPTY)
                {                
                    
                        break;
                    
                }
            }
        }
        
    }
    return false;
}
