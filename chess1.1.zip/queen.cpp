#include "game.h"
#include "board.h"
#include "queen.h"

const int DY[] = { -1, -1,  0,  1,  1,  1,  0, -1 };
const int DX[] = { 0,  1,  1,  1,  0, -1, -1, -1 };
                // N  NE   E  SE   S  SW   W  NW

Queen::Queen(Color color, int y, int x, Board* board) : Piece(color, y, x, board) {
    setLabel(letter(QUEEN));
    setScore(QUEEN_POINTS);
}

bool Queen::isMoveValid(int y, int x) {
    Board* board = getBoard();
    for (int d = 0; d < 8; d++) {        
            for (int l = 1; l < 8; l++)
            {
                //checking whether the target position is lies on the path
                if (y == getY() + l * DY[d] && x == getX() + l * DX[d]) {
                    Piece* target = board->get(getY() + DY[d], getX() + DX[d]);
                    // move to an empty cell or capture opponent piece
                    if (target == EMPTY || target->getColor() != this->getColor())
                        return true;
                }
                //checking whether the path is out of bound
                if (0 <= getY() + l * DY[d] && getY() + l * DY[d] < H && 0 <= getX() + l * DX[d] && getX() + l * DX[d] < W)
                {
                    //checking whether the path is blocked
                    if (board->get(getY() + l * DY[d], getX() + l * DX[d]) != EMPTY)
                    {
                        
                            break;
                        
                    }
                }
            }
        
       
    }
    return false;
}
